# frozen_string_literal: true
# Example 4: CSV.table Silently Corrupts Leading-Zero Strings via Octal
#
# CSV.table applies converters: :numeric by default, which calls Ruby's Integer()
# on every number-looking field. Ruby's Integer() follows C literal conventions:
# a leading zero means OCTAL. So "00123" becomes 83 (octal 0123 = decimal 83)
# and "01234" becomes 668 (octal 1234 = decimal 668).
# ZIP codes, customer IDs, order numbers — any leading-zero field becomes
# a completely wrong integer. No exception, no warning.

require 'csv'
require 'smarter_csv'
require 'awesome_print'

CSV_FILE = File.join(__dir__, 'example4.csv')

puts "=" * 60
puts "Example 4: CSV.table Silently Mis-interprests Leading-Zero Values as Octal ❌"
puts "=" * 60

puts "\n--- CSV file contents ---"
puts File.read(CSV_FILE)

puts "\n--- Ruby CSV.read default (no converters) — strings preserved ---"
rows = CSV.read(CSV_FILE, headers: true).map(&:to_h)
ap rows, index: false

puts "\n--- Ruby CSV.table (converters: :numeric by default) — OCTAL corruption ---"
rows = CSV.table(CSV_FILE).map(&:to_h)
ap rows, index: false
puts "\n=> customer_id: #{rows.first[:customer_id].inspect}  (\"00123\" interpreted as octal → decimal #{rows.first[:customer_id]}) ❌"
puts "=> zip_code:    #{rows.first[:zip_code].inspect}  (\"01234\" interpreted as octal → decimal #{rows.first[:zip_code]}) ❌"
puts "=> No exception. No warning. The values look like valid integers."

puts "\n--- Ruby CSV.read with converters: :numeric — same octal corruption ---"
rows = CSV.read(CSV_FILE, headers: true, converters: :numeric).map(&:to_h)
ap rows, index: false

puts "\n--- SmarterCSV default (decimal conversion, no octal trap) ---"
rows = SmarterCSV.process(CSV_FILE)
ap rows, index: false
puts "\n=> Decimal conversion: \"00123\" => #{rows.first[:customer_id]} (correct decimal value, leading zeros gone)"

puts "\n--- SmarterCSV convert_values_to_numeric: false (preserves strings exactly) ---"
rows = SmarterCSV.process(CSV_FILE, convert_values_to_numeric: false)
ap rows, index: false
puts "\n=> Strings preserved: customer_id => #{rows.first[:customer_id].inspect}, zip_code => #{rows.first[:zip_code].inspect}"
