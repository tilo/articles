# frozen_string_literal: true
# Example 9: TSV File Read as CSV — Entire Row Collapses to One Field
#
# CSV.read uses comma as the default column separator. If the file is actually
# tab-delimited (common with database exports, Excel "Save as Text", reporting
# tools), every row collapses to a single field containing the entire line —
# tabs and all. All column structure is silently lost.
# rows.length still looks right, no error is raised, and the data is all there
# — just jammed into one string per row.

require 'csv'
require 'smarter_csv'
require 'awesome_print'

CSV_FILE = File.join(__dir__, 'example9.csv')

puts "=" * 60
puts "Example 9: TSV File Read as CSV — One Field Per Row ❌"
puts "=" * 60

puts "\n--- CSV file contents (tab-delimited) ---"
puts File.read(CSV_FILE)

puts "\n--- Ruby CSV (default col_sep: ',') ---"
rows = CSV.read(CSV_FILE, headers: true).map(&:to_h)
puts "rows.length => #{rows.length}  (looks right — but...)"
ap rows, index: false
puts "\n=> Data is completely garbled and unusable ❌"
puts "\n=> rows.first['name']  => #{rows.first['name'].inspect}  (nil — column unreachable)"
puts "=> The only key is: #{rows.first.keys.first.inspect}"
puts "=> Entire header row is one key. Entire data row is one value. No error raised."

puts "\n--- SmarterCSV (col_sep: :auto, the default) ---"
rows = SmarterCSV.process(CSV_FILE)
ap rows, index: false
puts "\n=> col_sep: :auto detects the tab separator automatically. All columns parsed correctly."
