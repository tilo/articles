# frozen_string_literal: true
# Run all 10 examples in sequence.
# Each example shows the Ruby CSV failure followed by the SmarterCSV fix.

examples = Dir.glob(File.join(__dir__, 'example*/example*.rb')).sort

examples.each do |script|
  puts "\n"
#  puts "#" * 60
  system("ruby #{script}")
  puts
end
