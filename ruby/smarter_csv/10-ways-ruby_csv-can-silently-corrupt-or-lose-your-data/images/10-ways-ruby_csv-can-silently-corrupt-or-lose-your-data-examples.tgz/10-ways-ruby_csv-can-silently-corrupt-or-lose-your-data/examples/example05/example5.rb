# frozen_string_literal: true
# Example 5: Whitespace in Header Names — Silent nil on Lookup
#
# CSV.read returns headers exactly as they appear in the file, including
# leading and trailing whitespace. Lookups by the expected name return nil.

require 'csv'
require 'smarter_csv'
require 'awesome_print'

CSV_FILE = File.join(__dir__, 'example5.csv')

puts "=" * 60
puts "Example 5: Whitespace in Header Names"
puts "=" * 60

puts "\n--- CSV file contents ---"
puts File.read(CSV_FILE)

puts "\n--- Ruby CSV ---"
rows = CSV.read(CSV_FILE, headers: true).map(&:to_h)
ap rows, index: false
puts "\n=> Keys are \" name \" and \" age\", not \"name\" and \"age\"."
puts "=> rows.first['name'] => #{rows.first['name'].inspect}  (nil — silent miss)"
puts "=> rows.first['age']  => #{rows.first['age'].inspect}  (nil — silent miss)"

puts "\n--- Ruby CSV.table (mitigates this one case) ---"
rows = CSV.table(CSV_FILE).map(&:to_h)
ap rows, index: false
puts "\n=> CSV.table's :symbol converter calls .strip — whitespace removed from headers."

puts "\n--- SmarterCSV ---"
rows = SmarterCSV.process(CSV_FILE)
ap rows, index: false
puts "\n=> strip_whitespace: true (default) strips headers and values. :name and :age work correctly."
