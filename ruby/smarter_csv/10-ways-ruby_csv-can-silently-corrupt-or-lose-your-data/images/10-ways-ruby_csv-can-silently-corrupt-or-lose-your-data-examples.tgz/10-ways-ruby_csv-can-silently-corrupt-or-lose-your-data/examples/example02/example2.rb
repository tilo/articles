# frozen_string_literal: true
# Example 2: Duplicate Header Names — First Value Silently Dropped
#
# When two columns share the same header name, CSV::Row#to_h keeps only
# the first value. Subsequent values are silently discarded.

require 'csv'
require 'smarter_csv'
require 'awesome_print'

CSV_FILE = File.join(__dir__, 'example2.csv')

puts "=" * 60
puts "Example 2: Duplicate Header Names"
puts "=" * 60

puts "\n--- CSV file contents ---"
puts File.read(CSV_FILE)

puts "\n--- Ruby CSV ---"
rows = CSV.read(CSV_FILE, headers: true).map(&:to_h)
ap rows, index: false
puts "\n=> Second score (87) silently lost. Only first score (95) survives."

puts "\n--- SmarterCSV ---"
rows = SmarterCSV.process(CSV_FILE)
ap rows, index: false
puts "\n=> Both scores preserved: :score => 95, :score2 => 87."
