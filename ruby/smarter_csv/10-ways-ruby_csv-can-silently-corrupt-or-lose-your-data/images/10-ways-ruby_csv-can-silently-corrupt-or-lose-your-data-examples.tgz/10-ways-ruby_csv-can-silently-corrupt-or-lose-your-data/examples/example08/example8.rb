# frozen_string_literal: true
# Example 8: Backslash-Escaped Quotes — MySQL / Unix Dump Format
#
# MySQL SELECT INTO OUTFILE, PostgreSQL COPY TO, and many Unix tools escape
# embedded quotes as \" instead of "" (RFC 4180). Ruby CSV only understands
# RFC 4180, so \" is treated as a literal backslash followed by a closing quote
# — either crashing or silently garbling field boundaries.

require 'csv'
require 'smarter_csv'
require 'awesome_print'

CSV_FILE = File.join(__dir__, 'example8.csv')

puts "=" * 60
puts "Example 8: Backslash-Escaped Quotes (MySQL/Unix Format)"
puts "=" * 60

puts "\n--- CSV file contents ---"
puts File.read(CSV_FILE)

puts "\n--- Ruby CSV: Scenario 1 — default (raises) ---"
begin
  CSV.read(CSV_FILE, headers: true)
rescue => e
  puts "#{e.class}: #{e.message}"
end

puts "\n--- Ruby CSV: Scenario 2 — liberal_parsing: true (silent garbling) ---"
rows = CSV.read(CSV_FILE, headers: true, liberal_parsing: true).map(&:to_h)
ap rows, index: false
alice_note = rows[0]['note']
puts "\n=> rows[0]['note'] => #{alice_note.inspect}"
puts "=> Note has extra surrounding quotes — field was mis-parsed. No exception raised."

puts "\n--- SmarterCSV ---"
rows = SmarterCSV.process(CSV_FILE)
ap rows, index: false
puts "\n=> quote_escaping: :auto (default) detects backslash escaping and preserves"
puts "   field boundaries. Both rows parsed correctly. Value retains the \\\" sequences."
