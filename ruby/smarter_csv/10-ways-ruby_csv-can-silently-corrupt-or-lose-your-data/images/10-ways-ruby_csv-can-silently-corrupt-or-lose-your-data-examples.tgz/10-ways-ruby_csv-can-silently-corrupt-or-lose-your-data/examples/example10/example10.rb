# frozen_string_literal: true
# Example 10: No Encoding Auto-Detection — Crash or Mojibake
#
# CSV.read assumes UTF-8. Files exported from Excel on Windows are often
# Windows-1252 (CP1252). This causes either a crash or silent mojibake —
# garbled strings that pass .valid_encoding? and get stored in your database.

require 'csv'
require 'smarter_csv'
require 'awesome_print'

CSV_FILE = File.join(__dir__, 'example10.csv')

puts "=" * 60
puts "Example 10: No Encoding Auto-Detection"
puts "=" * 60

puts "\n--- CSV file contents (cat may garble the ü) ---"
puts File.read(CSV_FILE, encoding: 'windows-1252')

puts "\n--- Ruby CSV: Scenario 1 — default UTF-8 (crash) ---"
begin
  CSV.read(CSV_FILE, headers: true)
rescue => e
  puts "#{e.class}: #{e.message}"
end

puts "\n--- Ruby CSV: Scenario 2 — encoding: 'binary' (silent mojibake) ---"
rows = CSV.read(CSV_FILE, headers: true, encoding: 'binary').map(&:to_h)
ap rows, index: false
last_name = rows.first['last_name']
puts "\n=> last_name          => #{last_name.inspect}  (garbled)"
puts "=> valid_encoding?    => #{last_name.valid_encoding?}  (Ruby thinks it's fine!)"
puts "=> This gets stored in your database and surfaces as a display bug later."

puts "\n--- SmarterCSV ---"
rows = SmarterCSV.process(CSV_FILE, file_encoding: 'windows-1252:utf-8')
ap rows, index: false
puts "\n=> Correctly transcoded to UTF-8. :last_name => #{rows.first[:last_name].inspect}"
