# frozen_string_literal: true
# Example 1: Extra Columns Without Headers — Values Silently Discarded
#
# When a row has more fields than headers, CSV.read maps all extra fields
# to the nil key. Only the first extra value survives — the rest are silently lost.

require 'csv'
require 'smarter_csv'
require 'awesome_print'

CSV_FILE = File.join(__dir__, 'example1.csv')

puts "=" * 60
puts "Example 1: Extra Columns Without Headers"
puts "=" * 60

puts "\n--- CSV file contents ---"
puts File.read(CSV_FILE)

puts "\n--- Ruby CSV ---"
rows = CSV.read(CSV_FILE, headers: true).map(&:to_h)
ap rows, index: false
puts "\n=> 'Gold' is silently lost. Only the first extra value (' VIP') survives under nil."

puts "\n--- SmarterCSV ---"
rows = SmarterCSV.process(CSV_FILE)
ap rows, index: false
puts "\n=> Extra values auto-named :column_4, :column_5 (by position). Trailing empty dropped by remove_empty_values: true."
