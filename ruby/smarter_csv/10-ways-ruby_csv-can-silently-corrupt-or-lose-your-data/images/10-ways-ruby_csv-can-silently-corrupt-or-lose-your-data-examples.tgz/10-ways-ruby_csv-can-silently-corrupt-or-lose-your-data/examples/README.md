# 10 Ways Ruby CSV Can Silently Corrupt Your Data — Examples

Companion scripts for the article
**[10 Ways Ruby's CSV.read Can Silently Corrupt or Lose Your Data](https://dev.to/tilo_sloboda/10-ways-ruby_csv-can-silently-corrupt-or-lose-your-data)**.

Each directory contains a CSV fixture file and a Ruby script that demonstrates
the Ruby CSV failure followed by the SmarterCSV fix.

## Setup

```bash
gem install smarter_csv awesome_print
```

## Run a single example

```bash
ruby example01/example1.rb
```

## Run all examples

```bash
ruby run_all.rb
```

## Contents

| Directory | Issue |
|-----------|-------|
| example01 | Extra columns silently dropped |
| example02 | Duplicate headers — last value wins |
| example03 | Empty headers — `""` key collision |
| example04 | BOM corrupts the first header |
| example05 | Whitespace in header names |
| example06 | `liberal_parsing: true` garbles field values |
| example07 | `nil` vs `""` for empty fields |
| example08 | Backslash-escaped quotes (MySQL/Unix format) |
| example09 | Missing closing quote consumes the rest of the file |
| example10 | No encoding auto-detection — crash or mojibake |

## Notes

- `example04.csv` contains a real UTF-8 BOM (`\xEF\xBB\xBF`) — this is intentional.
- `example10.csv` is encoded in Windows-1252 — `ü` is stored as `\xFC`, not UTF-8.
- All other files are UTF-8.
