# frozen_string_literal: true
# Example 6: Whitespace Around Values — Silent Comparison Failure
#
# CSV.read returns field values exactly as they appear in the file — leading
# spaces, trailing spaces, and tab characters are all preserved. Exporters from
# fixed-width database systems (Oracle CHAR columns, COBOL-era systems) routinely
# pad fields; other tools leave accidental leading spaces. The values look correct
# when printed, but equality checks silently return false.
#
# This pairs with Example 5 (whitespace in headers): Ruby CSV strips neither
# headers nor values by default.

require 'csv'
require 'smarter_csv'
require 'awesome_print'

CSV_FILE = File.join(__dir__, 'example6.csv')

puts "=" * 60
puts "Example 6: Whitespace Around Values"
puts "=" * 60

puts "\n--- CSV file contents ---"
puts File.read(CSV_FILE)
puts "(Alice has trailing spaces after 'active'; Carol has a leading space before 'active')"

puts "\n--- Ruby CSV ---"
rows = CSV.read(CSV_FILE, headers: true).map(&:to_h)
ap rows, index: false
active_rows = rows.select { |r| r['status'] == 'active' }
puts "\n=> rows[0]['status'] => #{rows[0]['status'].inspect}"
puts "=> rows[2]['status'] => #{rows[2]['status'].inspect}"
puts "=> rows.select { |r| r['status'] == 'active' } => #{active_rows.length} rows"
puts "=> Alice and Carol are not found. No error raised."

puts "\n--- Ruby CSV (strip: true) ---"
rows = CSV.read(CSV_FILE, headers: true, strip: true).map(&:to_h)
active_rows = rows.select { |r| r['status'] == 'active' }
puts "=> rows.select { |r| r['status'] == 'active' } => #{active_rows.length} rows  (strip: true fixes spaces and tabs)"

puts "\n--- SmarterCSV ---"
rows = SmarterCSV.process(CSV_FILE)
ap rows, index: false
active_rows = rows.select { |r| r[:status] == 'active' }
puts "\n=> rows.select { |r| r[:status] == 'active' } => #{active_rows.length} rows"
puts "=> strip_whitespace: true (default) strips all leading/trailing whitespace from values."
