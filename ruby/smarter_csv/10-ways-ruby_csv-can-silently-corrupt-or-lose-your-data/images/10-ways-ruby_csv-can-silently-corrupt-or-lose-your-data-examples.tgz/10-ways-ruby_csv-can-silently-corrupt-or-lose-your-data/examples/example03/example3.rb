# frozen_string_literal: true
# Example 3: Empty Header Fields — "" Key Collision
#
# Blank header cells become nil keys. Multiple blank headers all collide
# on the same nil key — only the first value survives, the rest are lost.

require 'csv'
require 'smarter_csv'
require 'awesome_print'

CSV_FILE = File.join(__dir__, 'example3.csv')

puts "=" * 60
puts "Example 3: Empty Header Fields"
puts "=" * 60

puts "\n--- CSV file contents ---"
puts File.read(CSV_FILE)

puts "\n--- Ruby CSV (with headers: true) ---"
rows = CSV.read(CSV_FILE, headers: true).map(&:to_h)
ap rows, index: false
puts "\n=> 'bar' silently lost — both blank headers map to nil, first value wins."

puts "\n--- Ruby CSV.table (symbol keys) ---"
rows = CSV.table(CSV_FILE).map(&:to_h)
ap rows, index: false
puts "\n=> Same nil key collision. 'bar' still lost."

puts "\n--- SmarterCSV ---"
rows = SmarterCSV.process(CSV_FILE)
ap rows, index: false
puts "\n=> Blank headers auto-named :column_1, :column_2. Both values preserved."
