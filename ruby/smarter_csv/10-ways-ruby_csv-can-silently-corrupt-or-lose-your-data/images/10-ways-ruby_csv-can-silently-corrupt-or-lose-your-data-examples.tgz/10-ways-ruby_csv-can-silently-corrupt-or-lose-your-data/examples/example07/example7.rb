# frozen_string_literal: true
# Example 7: nil vs "" for Empty Fields — Inconsistent Empty Checks
#
# CSV.read returns nil for unquoted empty fields and "" for quoted empty
# fields. Same semantic meaning, different Ruby types — .nil?, .blank?,
# .present? all behave differently depending on how the exporter quoted it.

require 'csv'
require 'smarter_csv'
require 'awesome_print'

CSV_FILE = File.join(__dir__, 'example7.csv')

puts "=" * 60
puts "Example 7: nil vs \"\" for Empty Fields"
puts "=" * 60

puts "\n--- CSV file contents ---"
puts File.read(CSV_FILE)

puts "\n--- Ruby CSV ---"
rows = CSV.read(CSV_FILE, headers: true).map(&:to_h)
ap rows, index: false
puts "\n=> rows[0]['city'] => #{rows[0]['city'].inspect}  (unquoted empty → nil)"
puts "=> rows[1]['city'] => #{rows[1]['city'].inspect}    (quoted empty → \"\")"
puts "=> rows[0]['city'].nil? => #{rows[0]['city'].nil?}"
puts "=> rows[1]['city'].nil? => #{rows[1]['city'].nil?}   (same meaning, different type)"

puts "\n--- SmarterCSV (remove_empty_values: true, default) ---"
rows = SmarterCSV.process(CSV_FILE)
ap rows, index: false
puts "\n=> Both empty cities removed from the hash. Consistent and clean by default."

puts "\n--- SmarterCSV (remove_empty_values: false) ---"
rows = SmarterCSV.process(CSV_FILE, remove_empty_values: false)
ap rows, index: false
puts "\n=> Both normalized to \"\". Consistent either way."
